<?php
function format_results(array $scores, array $documents, int $limit = 10): array {
    $results = [];
    $count = 0;

    foreach ($scores as $docId => $score) {
        if (!isset($documents[$docId])) continue;

        $doc = $documents[$docId];
        $results[] = [
            'title' => $doc['title'],
            'description' => $doc['description'],
            'language' => $doc['language'],
            'score' => round($score, 4)
        ];

        if (++$count >= $limit) break;
    }
    return $results;
}

function format_es_results(array $hits): array {
    return array_map(fn($h) => [
        'title' => $h['_source']['title'],
        'description' => $h['_source']['description'],
        'language' => $h['_source']['language'],
        'score' => $h['_score']
    ], $hits);
}

