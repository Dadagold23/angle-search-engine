<?php
require_once __DIR__ . '/query-parser/parser.php';
require_once __DIR__ . '/intent-detection/intent.php';
require_once __DIR__ . '/retriever/retriever.php';
require_once __DIR__ . '/result-formatter/formatter.php';
require_once __DIR__ . '/../ranking/ranker.php';

// Load indexes
$index = json_decode(file_get_contents(__DIR__ . '/../storage/index/inverted_index.json'), true);
$documents = json_decode(file_get_contents(__DIR__ . '/../storage/index/documents.json'), true);
$geoIndex = json_decode(file_get_contents(__DIR__ . '/../storage/index/geo_index.json'), true);

// Input
$query = $_GET['q'] ?? '';
$userState = $_GET['state'] ?? null;

$tokens = parse_query($query);
$intent = detect_intent($tokens);

// Ranking
$scores = rank($tokens, $index, $documents, $geoIndex, $userState);

// Output
header('Content-Type: application/json');
echo json_encode([
    'query' => $query,
    'intent' => $intent,
    'results' => format_results($scores, $documents)
], JSON_PRETTY_PRINT);
