<?php
function parse_query(string $query): array {
    $query = strtolower(trim($query));
    $query = preg_replace('/[^a-z0-9\s]/', ' ', $query);
    return array_values(array_filter(explode(' ', $query)));
}
