<?php
require_once __DIR__ . '/../../index-storage/elasticsearch/client.php';

function retrieve_candidates(array $tokens, array $index): array {
    $candidates = [];

    foreach ($tokens as $token) {
        if (isset($index[$token])) {
            foreach ($index[$token] as $docId => $freq) {
                $candidates[$docId] = true;
            }
        }
    }
    return array_keys($candidates);
}

function elastic_search(string $query, ?string $state = null): array {
    $must = [
        [
            "multi_match" => [
                "query" => $query,
                "fields" => ["title", "description", "content"]
            ]
        ]
    ];

    if ($state) {
        $must[] = ["term" => ["geo" => $state]];
    }

    $body = [
        "query" => [
            "bool" => [
                "must" => $must
            ]
        ],
        "size" => 10
    ];

    $res = es_request("GET", "angle_pages/_search", $body);

    return $res['hits']['hits'] ?? [];
}
