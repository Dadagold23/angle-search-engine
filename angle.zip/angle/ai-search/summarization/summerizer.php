<?php
function summarize(string $text, int $sentences = 3): string {
    $chunks = preg_split('/(\.|\?|\!)/', $text);
    return implode('. ', array_slice($chunks, 0, $sentences)) . '.';
}
