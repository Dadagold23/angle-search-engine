<?php
require_once __DIR__ . '/context-builder/context.php';
require_once __DIR__ . '/answer-engine/answer.php';
require_once __DIR__ . '/summarization/summarizer.php';
require_once __DIR__ . '/question-answering/qa.php';

// Call Query Engine internally
$query = $_GET['q'] ?? '';

$response = json_decode(
    file_get_contents(
        "http://localhost/angle-search-engine/query-engine/search.php?q=" .
        urlencode($query)
    ),
    true
);

$results = $response['results'] ?? [];
$context = build_context($results);

$answer = question_answer($query, $context);

header('Content-Type: application/json');
echo json_encode([
    'query' => $query,
    'answer' => $answer,
    'summary' => summarize($context),
    'sources' => array_column($results, 'title')
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
