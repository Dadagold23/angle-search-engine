<?php
function generate_answer(string $query, string $context): string {
    if (stripos($query, 'what is') === 0) {
        return "Here is a clear explanation based on trusted sources:\n\n" . $context;
    }

    if (stripos($query, 'how') === 0) {
        return "Here is a step-by-step answer:\n\n" . $context;
    }

    return "Based on available information, here is what we found:\n\n" . $context;
}
