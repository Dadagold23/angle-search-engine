<?php
function build_context(array $rankedDocs, int $limit = 3): string {
    $context = [];

    foreach ($rankedDocs as $doc) {
        if (isset($doc['content'])) {
            $context[] = substr($doc['content'], 0, 600);
        }
        if (count($context) >= $limit) break;
    }

    return implode("\n\n", $context);
}
