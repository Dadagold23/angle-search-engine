<?php
function question_answer(string $query, string $context): string {
    if (stripos($query, 'who') === 0) {
        return summarize($context, 1);
    }
    if (stripos($query, 'when') === 0) {
        return summarize($context, 1);
    }
    if (stripos($query, 'where') === 0) {
        return summarize($context, 1);
    }
    return summarize($context, 2);
}
