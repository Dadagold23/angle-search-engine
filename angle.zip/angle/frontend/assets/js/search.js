const params = new URLSearchParams(window.location.search);
const query = params.get("q");

document.getElementById("queryInput").value = query;

if (query) {
  // AI Search
  fetch(`/angle-search-engine/ai-search/ai_search.php?q=${encodeURIComponent(query)}`)
    .then(res => res.json())
    .then(data => {
      document.querySelector("#aiAnswer p").innerText = data.answer;
    });

  // Normal Search
  fetch(`/angle-search-engine/query-engine/search.php?q=${encodeURIComponent(query)}`)
    .then(res => res.json())
    .then(data => {
      const resultsDiv = document.getElementById("results");
      resultsDiv.innerHTML = "";

      data.results.forEach(r => {
        resultsDiv.innerHTML += `
          <div class="result">
            <h3>${r.title}</h3>
            <p>${r.description}</p>
          </div>
        `;
      });
    });
}

// Load Ads
fetch(`/angle-search-engine/ads-system/ads.php?q=${encodeURIComponent(query)}`)
  .then(res => res.json())
  .then(ads => {
    const adsDiv = document.getElementById("ads");
    adsDiv.innerHTML = "";

    ads.forEach(ad => {
      adsDiv.innerHTML += `
        <div class="result">
          <small style="color:#1a73e8">Sponsored</small>
          <h3>${ad.title}</h3>
          <p>${ad.description}</p>
        </div>
      `;
    });
  });
