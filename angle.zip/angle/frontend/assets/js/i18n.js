const translations = {
  en: { placeholder: "Search the web with Angle" },
  yo: { placeholder: "Wa lori Ayelujara pelu Angle" },
  ha: { placeholder: "Bincika yanar gizo da Angle" },
  ig: { placeholder: "Chọọ ịntanetị na Angle" }
};

function setLanguage(lang) {
  document.querySelector("input[name='q']")
    .placeholder = translations[lang].placeholder;
}
