const input = document.querySelector("input[name='q']");
const box = document.createElement("div");
box.className = "autocomplete-box";
input.parentNode.appendChild(box);

input.addEventListener("input", () => {
  const q = input.value.trim();
  if (!q) {
    box.innerHTML = "";
    return;
  }

  fetch(`/angle-search-engine/api-gateway/rest/suggest.php?q=${q}`)
    .then(res => res.json())
    .then(data => {
      box.innerHTML = data.map(d =>
        `<div onclick="selectSuggestion('${d}')">${d}</div>`
      ).join("");
    });
});

function selectSuggestion(text) {
  input.value = text;
  box.innerHTML = "";
}
