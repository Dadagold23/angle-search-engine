<?php
require_once __DIR__ . '/tf-idf/tf_idf.php';
require_once __DIR__ . '/pagerank-like/pagerank.php';
require_once __DIR__ . '/freshness/freshness.php';
require_once __DIR__ . '/locality-boost/locality.php';
require_once __DIR__ . '/authority-score/authority.php';

function rank(
    array $queryTerms,
    array $index,
    array $documents,
    array $geoIndex,
    ?string $userState = null
): array {
    $scores = [];

    foreach ($documents as $docId => $doc) {
        $score = 0;

        foreach ($queryTerms as $term) {
            $score += tf_idf($term, $docId, $index);
        }

        $score *= authority_score($docId, []);
        $score *= locality_boost($docId, $userState, $geoIndex);

        $scores[$docId] = $score;
    }

    arsort($scores);
    return $scores;
}
