<?php
function authority_score(string $docId, array $pagerank): float {
    return $pagerank[$docId] ?? 0.1;
}
