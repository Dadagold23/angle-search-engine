<?php
function locality_boost(string $docId, ?string $userState, array $geoIndex): float {
    if (!$userState) return 1.0;
    return in_array($docId, $geoIndex[$userState] ?? [])
        ? 1.3
        : 1.0;
}
