<?php
function freshness_score(int $timestamp): float {
    $ageDays = (time() - $timestamp) / 86400;
    return exp(-0.05 * $ageDays);
}
