<?php
function tf_idf(string $term, string $docId, array $index): float {
    if (!isset($index[$term][$docId])) return 0.0;

    $tf = $index[$term][$docId];
    $docFreq = count($index[$term]);
    $totalDocs = count(array_unique(
        array_merge(...array_values($index))
    ));

    $idf = log(($totalDocs + 1) / ($docFreq + 1));
    return $tf * $idf;
}
