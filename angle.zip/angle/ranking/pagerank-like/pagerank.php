<?php
function pagerank(array $graph, int $iterations = 10): array {
    $rank = [];
    $n = count($graph);

    foreach ($graph as $node => $_) {
        $rank[$node] = 1 / $n;
    }

    for ($i = 0; $i < $iterations; $i++) {
        $newRank = [];
        foreach ($graph as $node => $links) {
            $sum = 0;
            foreach ($links as $link) {
                $sum += $rank[$link] ?? 0;
            }
            $newRank[$node] = 0.85 * $sum + 0.15 / $n;
        }
        $rank = $newRank;
    }
    return $rank;
}
