<?php
require_once __DIR__ . '/ad-ranking/auction.php';

$query = $_GET['q'] ?? '';
$state = $_GET['state'] ?? null;

$ads = run_ad_auction($query, $state);

header('Content-Type: application/json');
echo json_encode(array_map(fn($a) => [
    'title' => $a['ad']['title'],
    'description' => $a['ad']['description'],
    'url' => $a['ad']['url']
], $ads), JSON_PRETTY_PRINT);
