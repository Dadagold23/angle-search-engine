<?php
$id = $_GET['ad'] ?? '';
$log = date('Y-m-d H:i:s') . " | CLICK | $id\n";

file_put_contents(
    __DIR__ . '/../../storage/logs/ad_clicks.log',
    $log,
    FILE_APPEND
);

header("Location: " . ($_GET['url'] ?? '/'));
