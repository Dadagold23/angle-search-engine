<?php
function run_ad_auction(string $query, ?string $userState): array {
    $ads = json_decode(
        file_get_contents(__DIR__ . '/../ad-index/ads.json'),
        true
    );

    $query = strtolower($query);
    $scores = [];

    foreach ($ads as $ad) {
        // Geo targeting
        if ($userState && $ad['geo'] !== $userState) continue;

        $matchScore = 0;
        foreach ($ad['keywords'] as $kw) {
            if (str_contains($query, strtolower($kw))) {
                $matchScore += 1;
            }
        }

        if ($matchScore > 0) {
            // Final Ad Rank = bid × relevance
            $scores[] = [
                'ad' => $ad,
                'rank' => $ad['bid'] * $matchScore
            ];
        }
    }

    usort($scores, fn($a, $b) => $b['rank'] <=> $a['rank']);

    return array_slice($scores, 0, 3); // Top ads
}
