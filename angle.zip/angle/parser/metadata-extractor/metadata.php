<?php
function extract_metadata(string $html): array {
    preg_match('/<title>(.*?)<\/title>/is', $html, $title);
    preg_match('/<meta\s+name="description"\s+content="(.*?)"/is', $html, $desc);

    return [
        'title' => trim($title[1] ?? ''),
        'description' => trim($desc[1] ?? '')
    ];
}
