<?php
require_once __DIR__ . '/html-parser/html_parser.php';
require_once __DIR__ . '/metadata-extractor/metadata.php';
require_once __DIR__ . '/language-detector/language.php';
require_once __DIR__ . '/nlp-preprocessor/preprocessor.php';

$rawDir = __DIR__ . '/../storage/raw-pages';
$outDir = __DIR__ . '/../storage/processed-docs';

@mkdir($outDir, 0777, true);

foreach (glob("$rawDir/*.html") as $file) {
    $html = file_get_contents($file);

    $parsed = parse_html($html);
    $meta = extract_metadata($html);
    $lang = detect_language($parsed['text']);
    $cleanText = preprocess_text($parsed['text']);

    $doc = [
        'title' => $meta['title'],
        'description' => $meta['description'],
        'language' => $lang,
        'content' => $cleanText,
        'links' => $parsed['links']
    ];

    $id = basename($file, '.html');
    file_put_contents(
        "$outDir/$id.json",
        json_encode($doc, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
    );
}
