<?php
function parse_html(string $html): array {
    libxml_use_internal_errors(true);

    $dom = new DOMDocument();
    $dom->loadHTML($html);

    // Remove scripts & styles
    foreach (iterator_to_array($dom->getElementsByTagName('script')) as $el) {
        $el->parentNode->removeChild($el);
    }
    foreach (iterator_to_array($dom->getElementsByTagName('style')) as $el) {
        $el->parentNode->removeChild($el);
    }

    $text = trim(preg_replace('/\s+/', ' ', $dom->textContent));

    // Extract links
    $links = [];
    foreach ($dom->getElementsByTagName('a') as $a) {
        $href = $a->getAttribute('href');
        if (filter_var($href, FILTER_VALIDATE_URL)) {
            $links[] = $href;
        }
    }

    return [
        'text' => $text,
        'links' => array_unique($links)
    ];
}
