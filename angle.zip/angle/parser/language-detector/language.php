<?php
function detect_language(string $text): string {
    $patterns = [
        'yoruba' => ['ọ', 'ṣ', 'ẹ', 'ọba', 'àwọn'],
        'hausa'  => ['ɗ', 'ƙ', 'ts', 'ina', 'kuma'],
        'igbo'   => ['ụ', 'ị', 'anyị', 'nke'],
        'english'=> ['the', 'and', 'is', 'of']
    ];

    $scores = [];
    foreach ($patterns as $lang => $words) {
        $scores[$lang] = 0;
        foreach ($words as $w) {
            if (stripos($text, $w) !== false) {
                $scores[$lang]++;
            }
        }
    }

    arsort($scores);
    return array_key_first($scores);
}
