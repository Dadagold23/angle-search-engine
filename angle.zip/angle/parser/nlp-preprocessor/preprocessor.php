<?php
function preprocess_text(string $text): string {
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9\s]/u', ' ', $text);
    return trim(preg_replace('/\s+/', ' ', $text));
}
