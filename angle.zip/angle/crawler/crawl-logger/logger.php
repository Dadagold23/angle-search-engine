<?php
function log_crawl(string $url, string $status): void {
    $logDir = __DIR__ . '/../../storage/logs';
    @mkdir($logDir, 0777, true);

    $line = date('Y-m-d H:i:s') . " | $status | $url\n";
    file_put_contents("$logDir/crawler.log", $line, FILE_APPEND);
}
