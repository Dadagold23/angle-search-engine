<?php
class UrlScheduler {
    private array $queue = [];
    private array $visited = [];
    private int $maxDepth = 3;
    private int $maxPerDomain = 50;
    private array $domainCount = [];

    public function add(string $url, int $depth = 0): void {
        if ($depth > $this->maxDepth) return;

        $host = parse_url($url, PHP_URL_HOST);
        if (!$host) return;

        if (($this->domainCount[$host] ?? 0) >= $this->maxPerDomain) return;

        if (!isset($this->visited[$url])) {
            $this->queue[] = [
                'url' => $url,
                'depth' => $depth,
                'priority' => $depth
            ];
            $this->visited[$url] = true;
            $this->domainCount[$host] =
                ($this->domainCount[$host] ?? 0) + 1;
        }
    }

    public function next(): ?array {
        usort($this->queue, fn($a, $b) => $a['priority'] <=> $b['priority']);
        return array_shift($this->queue);
    }

    public function hasNext(): bool {
        return !empty($this->queue);
    }
}
