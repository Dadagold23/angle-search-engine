<?php
require_once __DIR__ . '/googlebot-like/crawler.php';
