<?php
function fetch_html(string $url): ?string {
    static $lastRequest = 0;
    $delay = 1; // seconds

    if (time() - $lastRequest < $delay) {
        sleep($delay);
    }
    $lastRequest = time();

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => 'AngleBot/1.5 (+https://anglesearch.ng/bot)',
        CURLOPT_TIMEOUT => 15
    ]);

    $html = curl_exec($ch);
    curl_close($ch);
    return $html ?: null;
}
