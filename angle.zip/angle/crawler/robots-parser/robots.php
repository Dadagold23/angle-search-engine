<?php
function is_allowed_by_robots(string $url): bool {
    $parsed = parse_url($url);
    $robotsUrl = $parsed['scheme'] . '://' . $parsed['host'] . '/robots.txt';

    $robots = @file_get_contents($robotsUrl);
    if (!$robots) return true; // No robots.txt → allowed

    foreach (explode("\n", $robots) as $line) {
        $line = trim($line);
        if (stripos($line, 'Disallow:') === 0) {
            $path = trim(str_replace('Disallow:', '', $line));
            if ($path !== '/' && str_contains($parsed['path'] ?? '/', $path)) {
                return false;
            }
        }
    }
    return true;
}
