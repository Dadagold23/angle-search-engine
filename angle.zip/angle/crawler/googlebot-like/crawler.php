<?php
require_once __DIR__ . '/../html-fetcher/fetcher.php';
require_once __DIR__ . '/../robots-parser/robots.php';
require_once __DIR__ . '/../url-scheduler/scheduler.php';
require_once __DIR__ . '/../sitemap-parser/sitemap.php';
require_once __DIR__ . '/../crawl-logger/logger.php';

$scheduler = new UrlScheduler();
$seed = 'https://example.com';

$scheduler->add($seed);

// Sitemap first (Google priority)
foreach (fetch_sitemap_urls($seed) as $sitemapUrl) {
    $scheduler->add($sitemapUrl, 0);
}

@mkdir(__DIR__ . '/../../storage/raw-pages', 0777, true);

while ($scheduler->hasNext()) {
    $item = $scheduler->next();
    $url = $item['url'];
    $depth = $item['depth'];

    if (!is_allowed_by_robots($url)) {
        log_crawl($url, 'BLOCKED_ROBOTS');
        continue;
    }

    $html = fetch_html($url);
    if (!$html) {
        log_crawl($url, 'FETCH_FAILED');
        continue;
    }

    $hash = md5($url);
    file_put_contents(
        __DIR__ . "/../../storage/raw-pages/$hash.html",
        $html
    );

    log_crawl($url, 'FETCHED');

    preg_match_all('/href="(http[^"#]+)"/i', $html, $matches);
    foreach ($matches[1] as $link) {
        $scheduler->add($link, $depth + 1);
    }
}
