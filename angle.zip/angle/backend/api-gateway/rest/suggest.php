<?php
$index = json_decode(
    file_get_contents('../../storage/index/inverted_index.json'),
    true
);

$q = strtolower($_GET['q'] ?? '');
$suggestions = [];

foreach ($index as $term => $_) {
    if (str_starts_with($term, $q)) {
        $suggestions[] = $term;
        if (count($suggestions) >= 5) break;
    }
}

echo json_encode($suggestions);
