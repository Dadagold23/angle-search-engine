<?php
require_once __DIR__ . '/tokenizer/tokenizer.php';
require_once __DIR__ . '/inverted-index/inverted_index.php';
require_once __DIR__ . '/document-mapper/document_mapper.php';
require_once __DIR__ . '/geo-index/nigeria_geo.php';
require_once __DIR__ . '/../index-storage/elasticsearch/index_document.php';

$processedDir = __DIR__ . '/../storage/processed-docs';
$indexDir = __DIR__ . '/../storage/index';

@mkdir($indexDir, 0777, true);

$invertedIndex = [];
$documents = [];
$geoIndex = [];

foreach (glob("$processedDir/*.json") as $file) {
    $doc = json_decode(file_get_contents($file), true);
    $docId = basename($file, '.json');

    $tokens = tokenize($doc['content']);
    add_to_index($invertedIndex, $tokens, $docId);

    $documents[$docId] = map_document($doc, $docId);

    $geo = detect_geo($doc['content']);
    if ($geo) {
        $geoIndex[$geo][] = $docId;
    }
}

// Persist indexes
file_put_contents("$indexDir/inverted_index.json", json_encode($invertedIndex));
file_put_contents("$indexDir/documents.json", json_encode($documents));
file_put_contents("$indexDir/geo_index.json", json_encode($geoIndex));

echo "Indexing complete.\n";

foreach (glob("$processedDir/*.json") as $file) {
    $doc = json_decode(file_get_contents($file), true);
    $docId = basename($file, '.json');

    index_document($docId, [
        "title" => $doc['title'],
        "description" => $doc['description'],
        "content" => $doc['content'],
        "language" => $doc['language'],
        "geo" => detect_geo($doc['content']),
        "created_at" => date('c')
    ]);
}
