<?php
function detect_geo(string $text): ?string {
    $states = [
        'lagos', 'oyo', 'kwara', 'abuja',
        'kano', 'ogun', 'ondo', 'osun',
        'katsina', 'rivers', 'anambra', 'enugu',
        'delta', 'ebonyi', 'akwa ibom', 'cross river',
        'bauchi', 'benue', 'borno', 'adamawa',
        'anambra', 'jigawa', 'nasarawa', 'kebbi',
        'sokoto', 'zamfara', 'yobe', 'taraba',
        'gombe', 'fct', 'federal capital territory',
        'plateau', 'niger', 'kogi',
        'ekiti', 'edo', 'yobe', 'bendel'

    ];  

    foreach ($states as $state) {
        if (stripos($text, $state) !== false) {
            return $state;
        }
    }
    return null;
}
