from elasticsearch import Elasticsearch, helpers
from datetime import datetime
import json

ES_HOST = "http://localhost:9200"
INDEX_NAME = "angle_geo_index"

es = Elasticsearch(ES_HOST)

def load_data(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)

def generate_actions(data):
    for doc in data:
        yield {
            "_index": INDEX_NAME,
            "_id": doc["id"],
            "_source": {
                **doc,
                "indexed_at": datetime.utcnow()
            }
        }

def ingest():
    data = load_data("nigeria_geo_data.json")
    helpers.bulk(es, generate_actions(data))
    print(f"Indexed {len(data)} Nigerian geo documents")

if __name__ == "__main__":
    ingest()
