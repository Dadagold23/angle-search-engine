<?php
function add_to_index(array &$index, array $tokens, string $docId): void {
    foreach ($tokens as $token) {
        if (!isset($index[$token])) {
            $index[$token] = [];
        }
        $index[$token][$docId] =
            ($index[$token][$docId] ?? 0) + 1;
    }
}
