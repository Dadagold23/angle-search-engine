<?php
function tokenize(string $text): array {
    $tokens = preg_split('/\s+/', $text);

    // Remove short tokens
    return array_values(array_filter($tokens, fn($t) => strlen($t) > 2));
}
