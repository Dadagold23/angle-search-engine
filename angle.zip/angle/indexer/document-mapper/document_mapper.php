<?php
function map_document(array $doc, string $docId): array {
    return [
        'id' => $docId,
        'title' => $doc['title'],
        'description' => $doc['description'],
        'language' => $doc['language']
    ];
}
