<?php
require_once 'client.php';

function index_document(string $id, array $doc) {
    return es_request(
        "PUT",
        "angle_pages/_doc/$id",
        $doc
    );
}
