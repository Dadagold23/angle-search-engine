<?php
function es_request(string $method, string $endpoint, array $body = null) {
    $ch = curl_init("http://localhost:9200/$endpoint");

    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => $body ? json_encode($body) : null
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}
