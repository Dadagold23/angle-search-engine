<?php
require_once 'client.php';

$mapping = [
  "mappings" => [
    "properties" => [
      "title" => ["type" => "text"],
      "description" => ["type" => "text"],
      "content" => ["type" => "text"],
      "language" => ["type" => "keyword"],
      "geo" => ["type" => "keyword"],
      "created_at" => ["type" => "date"]
    ]
  ]
];

$response = es_request("PUT", "angle_pages", $mapping);
print_r($response);
